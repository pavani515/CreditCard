package com.cg.creditcardpayment.service;

import com.cg.creditcardpayment.pojos.Admin;


public interface IAdminService {

	public Admin addAdmin(Admin admin);

}
