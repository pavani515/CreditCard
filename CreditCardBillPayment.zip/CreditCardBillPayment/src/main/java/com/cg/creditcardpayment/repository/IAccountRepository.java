package com.cg.creditcardpayment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.creditcardpayment.pojos.Account;

@Repository
public interface IAccountRepository extends JpaRepository<Account, Long> {
	
}
