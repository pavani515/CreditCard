package com.cg.creditcardpayment.service;

import java.util.List;

import com.cg.creditcardpayment.exceptions.AccountNotFoundException;
import com.cg.creditcardpayment.pojos.Account;

public interface IAccountService {
	
 Account addAccount(Account account);
 List<Account> deleteAccount(long id)throws AccountNotFoundException;
 Account updateAccount(Account account)throws AccountNotFoundException;
 Account getAccount(long id)throws AccountNotFoundException;
 List<Account> getAllAccounts();
 
}
