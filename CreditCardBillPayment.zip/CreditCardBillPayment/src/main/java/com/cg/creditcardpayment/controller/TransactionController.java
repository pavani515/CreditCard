package com.cg.creditcardpayment.controller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.creditcardpayment.pojos.Transaction;
import com.cg.creditcardpayment.service.ITransactionService;

@RestController

public class TransactionController {
		
		@Autowired
		ITransactionService service;

		
//		@PostMapping("/addTransaction")
//		public ResponseEntity<Transaction> addTransaction(@Valid @RequestBody Transaction transaction) {
//			Transaction transactionInfo = service.addTransaction(transaction);
//			return new ResponseEntity<Transaction>(transactionInfo, HttpStatus.OK);
//		}
//		
//		@PutMapping("/updateTransaction")
//		public ResponseEntity<Transaction> updateTransaction(@Valid @RequestBody Transaction transaction) {
//			Transaction transaction1 = service.updateTransaction(transaction);
//			return new ResponseEntity<Transaction>(transaction1, HttpStatus.OK);
//		}
//		
//		@DeleteMapping("/deleteTransaction/{transactionNumber}")
//		public ResponseEntity<List<Transaction>> deleteTransaction(@Valid @PathVariable int number) {
//			List<Transaction> transaction2 = service.deleteTransaction(number);
//			return new ResponseEntity<List<Transaction>>(transaction2, HttpStatus.OK);
//		}
//		
//		@GetMapping("/getTransaction/{number}")
//		public ResponseEntity<Transaction> getTransaction(@PathVariable("number") int number) {
//			Transaction transaction = service.getTransaction(number);
//			return new ResponseEntity<Transaction>(transaction, HttpStatus.OK);		
//		}
		
		/*
		 * This method gets all transaction details with the given cardNumber.
		 */
		@GetMapping("/getTransactions/{cardNumber}")
		public ResponseEntity<List<Transaction>> getTransaction(@PathVariable("cardNumber") String cardNumber) {
			List<Transaction> transaction = service.getAllCardTransactions(cardNumber);
			return new ResponseEntity<List<Transaction>>(transaction, HttpStatus.OK);		
		}

		/*
		 * This method views all transcations.
		 */
		@GetMapping("/getAllTransactions")
		public ResponseEntity<List<Transaction>> getTransaction() {
			List<Transaction> transaction = service.getAllTransactions();
			return new ResponseEntity<List<Transaction>>(transaction, HttpStatus.OK);
		}
	}

