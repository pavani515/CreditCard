package com.cg.creditcardpayment.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "User_Master")
public class User {
	@Id
	@Column(name = "user_id")
	private int id;
	@NotEmpty(message = "Password should not be null")
	@Size(min = 8, message = "Password should contain minimum 8 characters")
	@Pattern(regexp = "^.*(?=.{8,})(?=.*\\d)(?=.*[a-zA-Z])|(?=.{8,})(?=.*\\d)(?=.*[!@#$%^&])|(?=.{8,})(?=.*[a-zA-Z])(?=.*[!@#$%^&]).*$")
	private String password;
	private Boolean active;

	/*
	 * default constructor.
	 */
	public User() {

	}

	/*
	 * Parameterized constructor.
	 */
	public User(int id, String password) {
		this.id = id;
		this.password = password;
	}

	/*
	 * Parameterized constructor.
	 */
	public User(int id, String password, Boolean active) {
		super();
		this.id = id;
		this.password = password;
		// this.role = role;
		this.active = active;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	/*
	 * public User(int userId, String password) { super(); this.userId = userId;
	 * this.password = password; }
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [userId=" + id + ", password=" + password + "]";
	}

}
