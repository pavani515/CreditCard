package com.cg.creditcardpayment.pojos;

import java.time.LocalDate;

import java.util.List;
import javax.persistence.ManyToOne;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Customer_master")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int userId;

	@NotEmpty(message = " Name should not be empty")
	@Size(min = 4, message = "min 4 chars required")
	private String name;

	@Email
	private String email;

	@NotEmpty(message = " Contact should contain 10 digits")
	@Size(min = 10, message = "min 10 digits required")
	private String contactNo;

	private LocalDate dob;

	private String address;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_account")
	List<Account> Account;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "card_id")
	List<CreditCard> Creditcard;

	/*
	 * default constructor.
	 */
	public Customer() {
		super();
	}

	/*
	 * Parameterized constructor.
	 */
	public Customer(int userId, String name, String email, String contactNo, LocalDate dob, String address,
			List<Account> account, List<CreditCard> creditcard) {
		super();
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.dob = dob;
		this.address = address;
		Account = account;
		Creditcard = creditcard;
	}

	public Customer(String name, String email, String contactNo, LocalDate dob, String address, List<Account> account,
			List<CreditCard> creditcard) {
		super();
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.dob = dob;
		this.address = address;
		Account = account;
		Creditcard = creditcard;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Account> getAccount() {
		return Account;
	}

	public void setAccount(List<Account> account) {
		Account = account;
	}

	public List<CreditCard> getCreditcard() {
		return Creditcard;
	}

	public void setCreditcard(List<CreditCard> creditcard) {
		Creditcard = creditcard;
	}

	@Override
	public String toString() {
		return "Customer [userId=" + userId + ", name=" + name + ", email=" + email + ", contactNo=" + contactNo
				+ ", dob=" + dob + ", address=" + address + ", Account=" + Account + ", Creditcard=" + Creditcard + "]";
	}

}