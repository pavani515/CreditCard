package com.cg.creditcardpayment.pojos;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "account_master")

public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long number;

	@NotEmpty(message = " Account name should not be empty")
	private String name;

	private double balance;

	@NotEmpty(message = " Account Type should not be empty")
	private String type;
	/*
	 * default constructor.
	 */
	public Account() {
		super();
	}
	
	public Account(String name, double balance, String type) {
		super();
		this.name = name;
		this.balance = balance;
		this.type = type;
		
	}
	
	/*
	 * Parameterized constructor.
	 */
	public Account(long number, String name, double balance, String type) {
		super();
		this.number = number;
		this.name = name;
		this.balance = balance;
		this.type = type;
		
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Account [number=" + number + ", name=" + name + ", balance=" + balance + ", type=" + type + "]";
	}

}
