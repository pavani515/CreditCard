package com.cg.creditcardpayment.service;

import java.util.List;

import com.cg.creditcardpayment.exceptions.PaymentNotFoundException;
import com.cg.creditcardpayment.pojos.Payment;

public interface IPaymentService {

	
	public Payment addPayment(Payment payment);
	public List<Payment> removePayment(long id) throws PaymentNotFoundException;
	public Payment updatePayment(Payment payment) throws PaymentNotFoundException;
	public Payment getPayment(long id)throws PaymentNotFoundException;
	public List<Payment> getAllPayments();
}
