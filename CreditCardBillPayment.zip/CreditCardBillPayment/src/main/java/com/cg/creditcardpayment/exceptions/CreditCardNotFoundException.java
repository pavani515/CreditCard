package com.cg.creditcardpayment.exceptions;


@SuppressWarnings("serial")
public class CreditCardNotFoundException extends RuntimeException {
	
	public CreditCardNotFoundException(String message) {
	
		super(message);

}

	public CreditCardNotFoundException() {
		super();
	}

	public CreditCardNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public CreditCardNotFoundException(Throwable cause) {
		super(cause);
	}
}
