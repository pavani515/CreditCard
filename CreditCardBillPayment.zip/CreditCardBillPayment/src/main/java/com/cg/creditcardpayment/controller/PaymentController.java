package com.cg.creditcardpayment.controller;

import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.creditcardpayment.pojos.Payment;
import com.cg.creditcardpayment.service.IPaymentService;

@RestController


public class PaymentController {
	@Autowired
	IPaymentService service;
	/*
	 * This method adds the payment details
	 */
	@PostMapping("/addPayment")
	public ResponseEntity<Payment> addPayment(@Valid @RequestBody Payment payment){
			
		Payment paymentInfo = service.addPayment(payment);
		return new ResponseEntity<Payment>(paymentInfo, HttpStatus.OK);
		
		}
	/*
	 * This method gets the payment details with the given id.
	 */
	@GetMapping("/getPayment/{id}")
	public ResponseEntity<Payment> getPayment(@PathVariable("id") int id) {
		Payment payment = service.getPayment(id);
		return new ResponseEntity<Payment>(payment, HttpStatus.OK);
	}
	
	/*
	 * This method updates the payment details with the given id.
	 */
	@PutMapping("/updatePayment")
	public ResponseEntity<Payment> updatePayment(@Valid @RequestBody Payment payment) {
			Payment payment2 = service.updatePayment(payment);
			return new ResponseEntity<Payment>(payment2, HttpStatus.OK);
		}

	/*
	 * This method deletes the payment details
	 */
	@DeleteMapping("/removePayment/{id}")
	public ResponseEntity<List<Payment>> removePayment(@Valid @PathVariable int id) {
			List<Payment> payment1 = service.removePayment(id);
			return new ResponseEntity<List<Payment>>(payment1, HttpStatus.OK);
		} 
	
	/*
	 * This method views all payments.
	 */ 
	@GetMapping("/getAllPayments")
	public ResponseEntity<List<Payment>> getAllPayments() {
		List<Payment> card = service.getAllPayments();
		return new ResponseEntity<List<Payment>>(card, HttpStatus.OK);
	}
}
