package com.cg.creditcardpayment.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.creditcardpayment.pojos.Transaction;
import com.cg.creditcardpayment.repository.IStatementRepository;

@Service
@Transactional
public class StatementService implements IStatementService{
	@Autowired
	IStatementRepository repository;
	/*
	 * This method views all transcations between given dates.
	 */
	@Override
	public List<Transaction> getAllTransactionsBetweenDates(String cardNumber,Date startDate, Date endDate) {
		return repository.getAllTransactionsBetweenDates(cardNumber,startDate, endDate);
	}
	

}
