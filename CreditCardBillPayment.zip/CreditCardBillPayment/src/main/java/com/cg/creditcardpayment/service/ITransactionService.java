package com.cg.creditcardpayment.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.creditcardpayment.exceptions.TransactionNotFoundException;
import com.cg.creditcardpayment.pojos.Transaction;

public interface ITransactionService {

	Transaction addTransaction( Transaction transaction);
	Transaction getTransaction(int number) throws TransactionNotFoundException;

	List<Transaction> deleteTransaction(@Valid int number) throws TransactionNotFoundException;

    Transaction updateTransaction(@Valid Transaction transaction) throws TransactionNotFoundException;


	List<Transaction> getAllTransactions();
	List<Transaction> getAllCardTransactions(String cardNumber);	

}
