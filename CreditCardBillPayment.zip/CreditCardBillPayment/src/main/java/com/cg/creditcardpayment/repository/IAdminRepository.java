package com.cg.creditcardpayment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.creditcardpayment.pojos.Admin;


public interface IAdminRepository extends JpaRepository<Admin,Integer>{

	

	

}
