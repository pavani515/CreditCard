package com.cg.creditcardpayment.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.creditcardpayment.pojos.Transaction;



@Repository
public interface ITransactionRepository extends JpaRepository<Transaction, Integer> {

	
	public List<Transaction> findAllByCardNumber(String cardNumber);
}
