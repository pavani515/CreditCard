package com.cg.creditcardpayment.pojos;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin_Master")
public class Admin {
	@Id
	private int id;
	/*
	 * default constructor.
	 */
	public Admin() {

	}
	/*
	 * Parameterized constructor.
	 */
	public Admin(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Admin [AdminId=" + id + "]";
	}

}
