package com.cg.creditcardpayment.service;

import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.creditcardpayment.exceptions.UserNotFoundException;
import com.cg.creditcardpayment.pojos.User;
import com.cg.creditcardpayment.repository.IUserRepository;

@Service
@Transactional
public class UserService implements IUserService {
	@Autowired
	IUserRepository repository;
	/*
	 * This method is used to sign in the user
	 */
	@Override
	public User signIn(User user) {
		return repository.save(user);
	}
	/*
	 * This method is used to sign out the user
	 */
	@Override
	public User signOut(User user) {
		User user1 = repository.findById(user.getId()).get();
		repository.delete(user1);
		return user;
	}

	/*
	 * This method is used to change the password
	 */
	@Override
	public User changePassword( User user) throws UserNotFoundException {
		int id=user.getId();
		Optional<User> optional=repository.findById(id);
		if(!optional.isPresent())
			throw new UserNotFoundException("No user found to change password");
			return repository.save(user);
		
	}
	
}

