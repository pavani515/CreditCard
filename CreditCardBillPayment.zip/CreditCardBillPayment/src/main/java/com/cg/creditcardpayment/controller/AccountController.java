package com.cg.creditcardpayment.controller;

import java.util.List;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.creditcardpayment.pojos.Account;
import com.cg.creditcardpayment.service.IAccountService;

@RestController
//@RequestMapping("/api")
public class AccountController {
	@Autowired
	IAccountService accountService;
	/*
	 * This method adds the account details
	 */
	@PostMapping("/addAccount")
	public ResponseEntity<Account> addAccount(@Valid @RequestBody Account account) {
		Account accountinfo = accountService.addAccount(account);
		return new ResponseEntity<Account>(accountinfo, HttpStatus.OK);
	}
	/*
	 * This method removes account with given id .
	 */
	@DeleteMapping("/deleteAccount/{id}")
	public ResponseEntity<List<Account>> deleteAccount(@Valid @PathVariable long id) {
		//Account account = accountService.getAccount(id);
		List<Account> account2 = accountService.deleteAccount(id);
		return new ResponseEntity<List<Account>>(account2, HttpStatus.OK);

	}
	/*
	 * This method updates the account details
	 */
	@PutMapping("/updateAccount")
	public ResponseEntity<Account> updateAccount(@Valid @RequestBody Account account) {
		//Account accountinfo = accountService.getAccount(account.getNumber());
		Account account1 = accountService.updateAccount(account);
		return new ResponseEntity<Account>(account1, HttpStatus.OK);

	}
	/*
	 * This method get the account details for a given id.
	 */
	@GetMapping("/getAccount/{id}")
	public ResponseEntity<Account> getAccount(@PathVariable("id") long id) {
		Account account = accountService.getAccount(id);
		return new ResponseEntity<Account>(account, HttpStatus.OK);
	}
	/*
	 * This method views all accounts.
	 */
	@GetMapping("/getAllAccounts")
	public ResponseEntity<List<Account>> getAccounts() {
		List<Account> accounts = accountService.getAllAccounts();
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);

	}

}
