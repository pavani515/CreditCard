package com.cg.creditcardpayment.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.creditcardpayment.exceptions.TransactionNotFoundException;
import com.cg.creditcardpayment.pojos.Transaction;
import com.cg.creditcardpayment.repository.ITransactionRepository;

@Service
@Transactional
public class TransactionService implements ITransactionService {
	@Autowired
	ITransactionRepository repository;

	@Override
	public Transaction addTransaction(Transaction transaction) {
		return repository.save(transaction);
	}

	@Override
	public List<Transaction> deleteTransaction(int number) throws TransactionNotFoundException {
		Optional<Transaction> optional= repository.findById(number);
		if(!optional.isPresent())		 
			throw new TransactionNotFoundException("No Transaction found with given id "+number);
		else{
			Transaction transaction = repository.findById(number).get();
			repository.delete(transaction);
			return getAllTransactions();
		}
		
	}

	@Override
	public Transaction updateTransaction(Transaction transaction) throws TransactionNotFoundException {
		int id=transaction.getNumber();
		Optional<Transaction> optional=repository.findById(id);
		if(!optional.isPresent())
			throw new TransactionNotFoundException("No Record found to update");
		return repository.save(transaction);
	}
	@Override
	public Transaction getTransaction(int number) throws TransactionNotFoundException{
		Optional<Transaction> optional=	repository.findById(number);  
		if(!optional.isPresent())		 
			throw new TransactionNotFoundException("No Transaction found with given id "+number);	
		return optional.get();    
	}
	/*
	 * This method views all transactions.
	 */
	@Override
	public List<Transaction> getAllTransactions() {
		return repository.findAll();
	}
	/*
	 * This method gets all transaction details with the given cardNumber.
	 */
	@Override
	public List<Transaction> getAllCardTransactions(String cardNumber) {
		return repository.findAllByCardNumber(cardNumber);
	}

}
