package com.cg.creditcardpayment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.creditcardpayment.pojos.Admin;
import com.cg.creditcardpayment.service.IAdminService;


@RestController

public class AdminController {
	@Autowired
	IAdminService adminService;
	/*
	 * This method adds the admin details
	 */
	@PostMapping("/addAdmin")
	public ResponseEntity<Admin> addAdmin(@RequestBody Admin admin) {
		Admin adminInfo = adminService.addAdmin(admin);
		return new ResponseEntity<Admin>(adminInfo,HttpStatus.OK );
		
		
	}
}
