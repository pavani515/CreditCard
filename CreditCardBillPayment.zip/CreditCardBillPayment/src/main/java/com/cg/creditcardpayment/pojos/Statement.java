package com.cg.creditcardpayment.pojos;
import java.sql.Date;
import org.springframework.beans.factory.annotation.Autowired;


public class Statement {

	private Date startDate;
	private Date endDate;

	@Autowired
	private Transaction transaction;
	/*
	 * default constructor.
	 */
	public Statement() {
		super();
	}
	/*
	 * Parameterized constructor.
	 */
	public Statement(Date startDate, Date endDate, Transaction transaction) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.transaction = transaction;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "Statement [startDate=" + startDate + ", endDate=" + endDate + ", transaction=" + transaction + "]";
	}

}


