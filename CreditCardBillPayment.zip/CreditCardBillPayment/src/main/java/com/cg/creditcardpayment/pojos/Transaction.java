package com.cg.creditcardpayment.pojos;

import java.sql.Date;

import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "transaction_master")
public class Transaction {
	private String status;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int number;
	private Date date;
	@UpdateTimestamp
	private LocalTime time;
	@NotEmpty(message = "Card Number should contains 16 digits")
	@Size(min = 16, message = "min 16 digits")
	private String cardNumber;
	@Pattern(regexp = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$",message = "Appropriate email need to be entered")
	private String email;
	@Size(min = 10, message = "min 10 digits")
	private String mobileNumber;
	private double paymentAmount;
	@NotEmpty(message = "Card Number should contains 16 digits")
	private String payFrom;

	/*
	 * default constructor.
	 */
	public Transaction() {
		super();
	}
	/*
	 * Parameterized constructor.
	 */
	public Transaction(String status, int number, Date date, LocalTime time,String cardNumber,String email,String mobileNumber, double paymentAmount, String payFrom) {
		super();
		this.status = status;
		this.number = number;
		this.date = date;
		this.time = time;
		this.cardNumber = cardNumber;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.paymentAmount = paymentAmount;
		this.payFrom = payFrom;
	}

	/*
	 * Parameterized constructor.
	 */
	public Transaction(String status,Date date, LocalTime time,String cardNumber,String email,String mobileNumber, double paymentAmount, String payFrom) {
		super();
		this.status = status;
		this.date = date;
		this.time = time;
		this.cardNumber = cardNumber;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.paymentAmount = paymentAmount;
		this.payFrom = payFrom;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public LocalTime getTime() {
		return time;
	}
	public void setTime(LocalTime time) {
		this.time = time;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getPayFrom() {
		return payFrom;
	}
	public void setPayFrom(String payFrom) {
		this.payFrom = payFrom;
	}
	@Override
	public String toString() {
		return "Transaction [status=" + status + ", number=" + number + ", date=" + date + ", time=" + time
				+ ", cardNumber=" + cardNumber + ", email=" + email + ", mobileNumber=" + mobileNumber
				+ ", paymentAmount=" + paymentAmount + ", payFrom=" + payFrom + "]";
	}
}