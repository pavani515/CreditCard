package com.cg.creditcardpayment.service;

import java.util.List;

import com.cg.creditcardpayment.exceptions.CreditCardNotFoundException;
import com.cg.creditcardpayment.pojos.CreditCard;

public interface ICreditCardService {

	CreditCard getCreditCard(long id) throws CreditCardNotFoundException;

	CreditCard addCreditCard(CreditCard card);

	List<CreditCard> getAllCreditCards();

	CreditCard updateCreditCard(CreditCard card) throws CreditCardNotFoundException ;

	List<CreditCard> deleteCreditCard(long cardId) throws CreditCardNotFoundException;

	List<CreditCard> getAllCardDetails(String number);

}
