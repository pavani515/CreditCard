package com.cg.creditcardpayment.exceptions;

@SuppressWarnings("serial")
public class PaymentNotFoundException extends RuntimeException {
	public PaymentNotFoundException(String message) {
		
		super(message);

}

	public PaymentNotFoundException() {
		super();
	}

	public PaymentNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public PaymentNotFoundException(Throwable cause) {
		super(cause);
	}
}
