package com.cg.creditcardpayment.controller;

import org.springframework.web.bind.annotation.RestController;


import com.cg.creditcardpayment.pojos.Transaction;
import com.cg.creditcardpayment.service.IStatementService;


import java.sql.Date;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
public class StatementController {
	@Autowired
	IStatementService service;
	/*
	 * This method views all transcations between given dates.
	 */
	@GetMapping("transaction/{cardNumber}/{startDate}/{endDate}")
	public ResponseEntity<List<Transaction>> getAllTransactionsBetweenDates(@PathVariable String cardNumber,@PathVariable Date startDate, @PathVariable Date endDate) {
		List<Transaction> statement=service.getAllTransactionsBetweenDates(cardNumber,startDate, endDate);
		return new ResponseEntity<List<Transaction>>(statement, HttpStatus.OK);
	}
}
