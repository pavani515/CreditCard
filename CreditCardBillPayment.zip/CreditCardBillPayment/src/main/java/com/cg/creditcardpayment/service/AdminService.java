package com.cg.creditcardpayment.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.creditcardpayment.pojos.Admin;
import com.cg.creditcardpayment.repository.IAdminRepository;

@Service
@Transactional
public class AdminService implements IAdminService{
	@Autowired
	IAdminRepository repository;
	/*
	 * This method adds the Admin details
	 */
	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return repository.save(admin);
	}

	

	

	

	
	
	
	
	

	
	

	
}
