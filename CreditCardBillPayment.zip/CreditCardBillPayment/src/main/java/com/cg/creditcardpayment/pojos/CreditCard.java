package com.cg.creditcardpayment.pojos;

import java.time.LocalDate;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "credit_card_master")
public class CreditCard {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;
	
	@NotEmpty(message = " Bank name should not be empty")
	@Size(min = 4, message = "min 4 chars required")
	private String bankName;
	
	@NotEmpty(message = "Card type should not be empty")
	@Size(min = 4, message = "min 4 chars required")
	private String type;
	
	@NotEmpty(message = "Card name should not be empty")
	@Size(min = 4, message = "min 4 chars required")
	private String name;
	
	@NotEmpty(message = "Card Number should contains 16 digits")
	@Size(min = 16, message = "min 16 digits")
	private String number;
	
	private LocalDate expiryDate;
	private int cvv;
	
	/*
	 * default constructor.
	 */
	public CreditCard() {
		super();
	}
	/*
	 * Parameterized constructor.
	 */
	public CreditCard(long id, String bankName,String type, String name, String number,	LocalDate expiryDate, int cvv) {
		super();
		this.id = id;
		this.bankName = bankName;
		this.type = type;
		this.name = name;
		this.number = number;
		this.expiryDate = expiryDate;
		this.cvv = cvv;
	}
	/*
	 * Parameterized constructor.
	 */
	public CreditCard(String bankName,String type, String name, String number,	LocalDate expiryDate, int cvv) {
		super();
		this.bankName = bankName;
		this.type = type;
		this.name = name;
		this.number = number;
		this.expiryDate = expiryDate;
		this.cvv = cvv;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	@Override
	public String toString() {
		return "CreditCard [id=" + id + ", bankName=" + bankName + ", type=" + type + ", name=" + name + ", number="
				+ number + ", expiryDate=" + expiryDate + ", cvv=" + cvv + "]";
	}

}

	