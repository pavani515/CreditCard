package com.cg.creditcardpayment.service;

import java.sql.Date;
import java.util.List;


import com.cg.creditcardpayment.pojos.Transaction;

public interface IStatementService {
	
	public List<Transaction> getAllTransactionsBetweenDates(String cardNumber,Date startDate, Date endDate);

	
}
