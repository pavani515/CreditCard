package com.cg.creditcardpayment.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.creditcardpayment.exceptions.AccountNotFoundException;
import com.cg.creditcardpayment.pojos.Account;
import com.cg.creditcardpayment.repository.IAccountRepository;


@Service
@Transactional
public class AccountService implements IAccountService {

	@Autowired
	IAccountRepository repository;

	/*
	 * This method adds the account details
	 */
	@Override
	public Account addAccount(Account account) {
		return repository.save(account);
	}

	/*
	 * This method removes account with given id .
	 */
	@Override
	public List<Account> deleteAccount(long id) throws AccountNotFoundException {
		Optional<Account> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new AccountNotFoundException("Account Details not found for id " + id);
		else {
			Account account = repository.findById(id).get();
			repository.delete(account);
			return getAllAccounts();
		}
	}

	/*
	 * This method updates the account details
	 */
	@Override
	public Account updateAccount(Account account) throws AccountNotFoundException {
		long accountId = account.getNumber();
		Optional<Account> optional = repository.findById(accountId);
		if (!optional.isPresent())
			throw new AccountNotFoundException("No record found to update");
		return repository.save(account);

	}

	/*
	 * This method get the account details for a given id.
	 */
	@Override
	public Account getAccount(long id) throws AccountNotFoundException {
		Optional<Account> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new AccountNotFoundException("Account details not found for given id " + id);
		return optional.get();
	}

	/*
	 * This method views all accounts.
	 */
	@Override
	public List<Account> getAllAccounts() {
		return repository.findAll();
	}

}
