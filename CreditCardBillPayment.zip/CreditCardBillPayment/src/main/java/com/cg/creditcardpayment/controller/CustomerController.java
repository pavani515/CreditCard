package com.cg.creditcardpayment.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.creditcardpayment.pojos.Customer;
import com.cg.creditcardpayment.service.ICustomerService;


@RestController
//@RequestMapping("/api")
public class CustomerController {
	
@Autowired
ICustomerService service;
/*
 * This method adds the customer details
 */
@PostMapping("/addCustomer")
public ResponseEntity<Customer> addCustomer(@Valid @RequestBody Customer customer)
{
	Customer custinfo=service.addCustomer(customer);
	return new ResponseEntity<Customer>(custinfo,HttpStatus.OK);
}
/*
 * This method gets the customer details with the given id.
 */
@GetMapping("/getCustomer/{id}")
public ResponseEntity<Customer> getCustomer(@PathVariable("id") int id){
	Customer cust=service.getCustomer(id);
	return new ResponseEntity<Customer>(cust,HttpStatus.OK);
}
/*
 * This method views all customer details.
 */
@GetMapping("/getAllCustomers")
public ResponseEntity<List<Customer>> getCustomers(){
	List<Customer> cust=service.getAllCustomers();
	return new ResponseEntity<List<Customer>>(cust,HttpStatus.OK);
	
}
/*
 * This method updates the customer details with the given id.
 */
@PutMapping("/updateCustomer")
public ResponseEntity<Customer> updateCustomer(@Valid @RequestBody Customer customer) {
	Customer customer1=service.updateCustomer(customer);
		return new ResponseEntity<Customer>(customer1,HttpStatus.OK);
}
/*
 * This method deletes the customer details
 */
@DeleteMapping("/deleteCustomer/{id}")
public ResponseEntity<List<Customer>> deleteCustomer(@Valid @PathVariable int id){
	List<Customer> customer2=service.deleteCustomer(id);
		return new ResponseEntity<List<Customer>>(customer2,HttpStatus.OK);
	
	

 
}}