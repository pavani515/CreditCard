package com.cg.creditcardpayment.service;

import java.util.List;

import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.creditcardpayment.exceptions.PaymentNotFoundException;
import com.cg.creditcardpayment.pojos.Payment;
import com.cg.creditcardpayment.repository.IPaymentRepository;


@Service
@Transactional
public class PaymentService implements IPaymentService {

	@Autowired
	IPaymentRepository repository;
	/*
	 * This method adds the Payment details
	 */
	@Override
	public Payment addPayment(Payment payment) {
		return repository.save(payment);
	}
	/*
	 * This method deletes the payment details
	 */
	@Override
	public List<Payment> removePayment(long id) throws PaymentNotFoundException {
        Optional<Payment> optional=repository.findById(id);
		if(!optional.isPresent())
			throw new PaymentNotFoundException("Payment Details not found for id "+id);
		else {
			Payment payment=repository.findById(id).get();
		repository.delete(payment);
		return getAllPayments();
		}
	}
	
	/*
	 * This method updates the payment details with the given id.
	 */

	@Override
	public Payment updatePayment(Payment payment) throws PaymentNotFoundException {
		long paymentId = payment.getId();
		Optional<Payment> optional=repository.findById(paymentId);
		if(!optional.isPresent())
		throw new PaymentNotFoundException("No record found to update");
		return repository.save(payment);
	}
	
	
	/*
	 * This method gets the payment details with the given id.
	 */
	@Override
	public Payment getPayment(long id) throws PaymentNotFoundException{
		Optional<Payment> optional=repository.findById(id);
		if(!optional.isPresent())
			throw new PaymentNotFoundException("Payment Details not found for id "+id);	
		return optional.get();
	}
	
	/*
	 * This method views all payments.
	 */
	@Override
	public List<Payment> getAllPayments() {
		return repository.findAll();
	}

}
