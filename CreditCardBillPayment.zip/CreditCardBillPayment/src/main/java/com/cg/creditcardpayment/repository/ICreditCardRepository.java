package com.cg.creditcardpayment.repository;

import org.springframework.stereotype.Repository;

import com.cg.creditcardpayment.pojos.CreditCard;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ICreditCardRepository extends JpaRepository<CreditCard, Long> {

	
	public List<CreditCard> findAllByNumber(String number);
}
