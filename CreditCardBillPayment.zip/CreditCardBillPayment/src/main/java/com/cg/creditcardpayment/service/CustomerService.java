package com.cg.creditcardpayment.service;

import java.util.List;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.creditcardpayment.exceptions.CustomerNotFoundException;
import com.cg.creditcardpayment.pojos.Customer;
import com.cg.creditcardpayment.repository.ICustomerRepository;

@Service
@Transactional
public class CustomerService implements ICustomerService {
	@Autowired
	ICustomerRepository repository;

	/*
	 * This method adds the Customer details
	 */
	@Override
	public Customer addCustomer(Customer customer) {
		return repository.save(customer);
	}

	/*
	 * This method deletes the customer details
	 */
	@Override
	public List<Customer> deleteCustomer(int id) throws CustomerNotFoundException {
		Optional<Customer> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new CustomerNotFoundException("Customer details not found for id " + id);
		else {
			Customer customer = repository.findById(id).get();

			repository.delete(customer);
			return getAllCustomers();
		}
	}

	/*
	 * This method updates the customer details with the given id.
	 */

	@Override
	public Customer updateCustomer(Customer customer) throws CustomerNotFoundException {
		int customerId = customer.getUserId();
		Optional<Customer> optional = repository.findById(customerId);
		if (!optional.isPresent())
			throw new CustomerNotFoundException("No Record found to update");
		return repository.save(customer);

	}

	/*
	 * This method gets the customer details with the given id.
	 */

	@Override
	public Customer getCustomer(int id) throws CustomerNotFoundException {
		Optional<Customer> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new CustomerNotFoundException("Customer Details not found for id " + id);
		return optional.get();

	}

	/*
	 * This method gets all the customer details
	 */

	@Override
	public List<Customer> getAllCustomers() {
		return repository.findAll();
	}

}