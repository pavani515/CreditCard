package com.cg.creditcardpayment.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.creditcardpayment.pojos.User;
import com.cg.creditcardpayment.service.IUserService;

@RestController

public class UserController {
	@Autowired
	IUserService service;
	/*
	 * This method is used to sign in the user
	 */
	@PostMapping("/signIn")
	public ResponseEntity<User> signIn(@Valid @RequestBody User user) {
		User userInfo = service.signIn(user);
		return new ResponseEntity<User>(userInfo,HttpStatus.OK );
		
		
	}
	/*
	 * This method is used to sign out the user
	 */
	@DeleteMapping("/signOut")
	public ResponseEntity<User> signOut(@Valid @RequestBody User user) {
		User userInfo = service.signOut(user);
		return new ResponseEntity<User>(userInfo, HttpStatus.OK);
	}
	/*
	 * This method is used to change the password
	 */
	@PutMapping("/changePassword")
	public ResponseEntity<User> changePassword(@Valid @RequestBody User user) {
		User user2 = service.changePassword( user);
		return new ResponseEntity<User>(user2, HttpStatus.OK);
		
	
}
	
}
