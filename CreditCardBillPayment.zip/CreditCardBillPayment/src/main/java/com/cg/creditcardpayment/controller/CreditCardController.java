package com.cg.creditcardpayment.controller;


import java.util.List;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.creditcardpayment.pojos.CreditCard;
import com.cg.creditcardpayment.service.ICreditCardService;
@RestController
public class CreditCardController {
	
	@Autowired
	ICreditCardService service;

	/*
	 * This method adds the CreditCard details
	 */
	
	@PostMapping("/addCreditCard")
	public ResponseEntity<CreditCard> addCreditCard(@Valid @RequestBody CreditCard card) {
		CreditCard cardInfo = service.addCreditCard(card);
		return new ResponseEntity<CreditCard>(cardInfo, HttpStatus.OK);
	}
	/*
	 * This method update the creditcard details with given id
	 */
	@PutMapping("/updateCreditCard")
	public ResponseEntity<CreditCard> updateCard(@Valid @RequestBody CreditCard card) {
		CreditCard card1 = service.updateCreditCard(card);
		return new ResponseEntity<CreditCard>(card1, HttpStatus.OK);
	}
	/*
	 * This method deletes the creditcard details with given id
	 */
	@DeleteMapping("/deleteCreditCard/{cardId}")
	public ResponseEntity<List<CreditCard>> deleteCreditCard(@Valid @PathVariable long id) {
		List<CreditCard> card2 = service.deleteCreditCard(id);
		return new ResponseEntity<List<CreditCard>>(card2, HttpStatus.OK);
	}
	/*
	 * This method gets the creditcard details with the given id.
	 */
	@GetMapping("/getCreditCard/{cardId}")
	public ResponseEntity<CreditCard> getCreditCard(@PathVariable("cardId") long id) {
		CreditCard card = service.getCreditCard(id);
		return new ResponseEntity<CreditCard>(card, HttpStatus.OK);
	}
	/*
	 * This method gets the creditcard details with the given number.
	 */
	@GetMapping("/getCreditCards/{number}")
	public ResponseEntity<List<CreditCard>> getCreditCard(@PathVariable("number") String number) {
		List<CreditCard> creditcard = service.getAllCardDetails(number);
		return new ResponseEntity<List<CreditCard>>(creditcard, HttpStatus.OK);		
	}
	/*
	 * This method views all creditcards.
	 */
	@GetMapping("/getAllCreditCards")
	public ResponseEntity<List<CreditCard>> getCreditCard() {
		List<CreditCard> card = service.getAllCreditCards();
		return new ResponseEntity<List<CreditCard>>(card, HttpStatus.OK);
	}
	
}
