package com.cg.creditcardpayment.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.creditcardpayment.pojos.Transaction;

@Repository
public interface IStatementRepository extends JpaRepository<Transaction, Integer> {

	@Query(value = "from Transaction t where cardNumber=:cardNumber AND date BETWEEN :startDate AND :endDate")
	public List<Transaction> getAllTransactionsBetweenDates(@Param("cardNumber")String cardNumber, @Param("startDate")Date startDate,@Param("endDate")Date endDate);
}
