package com.cg.creditcardpayment.service;

import com.cg.creditcardpayment.exceptions.CustomerNotFoundException;
import com.cg.creditcardpayment.pojos.Customer;

import java.util.*;

public interface ICustomerService {
	Customer addCustomer(Customer customer);

	List<Customer> deleteCustomer(int id) throws CustomerNotFoundException;

	Customer updateCustomer(Customer customer) throws CustomerNotFoundException;

	Customer getCustomer(int id) throws CustomerNotFoundException;

	List<Customer> getAllCustomers();
}
