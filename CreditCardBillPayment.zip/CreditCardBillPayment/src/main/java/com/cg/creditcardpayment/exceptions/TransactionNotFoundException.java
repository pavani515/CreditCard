package com.cg.creditcardpayment.exceptions;
	
	@SuppressWarnings("serial")
	public class TransactionNotFoundException extends RuntimeException {
		
		public TransactionNotFoundException(String message) {
		
			super(message);

	}

		public TransactionNotFoundException() {
			super();
		}

		public TransactionNotFoundException(String message, Throwable cause) {
			super(message, cause);
		}

		public TransactionNotFoundException(Throwable cause) {
			super(cause);
		}
	}

