package com.cg.creditcardpayment.service;

import java.util.List;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.creditcardpayment.exceptions.CreditCardNotFoundException;
import com.cg.creditcardpayment.pojos.CreditCard;
import com.cg.creditcardpayment.repository.ICreditCardRepository;

@Service
@Transactional
public class CreditCardService implements ICreditCardService {
	
	@Autowired
	ICreditCardRepository repository;
	/*
	 * This method gets the creditcard details with the given id.
	 */
	@Override
	public CreditCard getCreditCard(long id) throws CreditCardNotFoundException{
		Optional<CreditCard> optional=	repository.findById(id);  
		if(!optional.isPresent())		 
			throw new CreditCardNotFoundException("Credit Card Details not found for id "+id);	
		return optional.get();    
	}
	/*
	 * This method adds the CreditCard details
	 */
	@Override
	public CreditCard addCreditCard(CreditCard card) {
		return repository.save(card);
	}
	/*
	 * This method views all creditcards.
	 */
	@Override
	public List<CreditCard> getAllCreditCards() {
		return repository.findAll();
	}
	/*
	 * This method updates the creditcard details with the given id.
	 */
	@Override
	public CreditCard updateCreditCard(CreditCard card) throws CreditCardNotFoundException{
		long id=card.getId();
		Optional<CreditCard> optional=repository.findById(id);
		if(!optional.isPresent())
			throw new CreditCardNotFoundException("No Record found to update");
		return repository.save(card);
	}
	/*
	 * This method deletes the creditcard details
	 */
	@Override
	public List<CreditCard> deleteCreditCard(long id) throws CreditCardNotFoundException{
		Optional<CreditCard> optional= repository.findById(id);
		if(!optional.isPresent())		 
			throw new CreditCardNotFoundException("Credit Card Details not found for id "+id);
		else{
			CreditCard card = repository.findById(id).get();
			repository.delete(card);
			return getAllCreditCards();
		}
	}
	/*
	 * This method views all creditcards.
	 */
	@Override
	public List<CreditCard> getAllCardDetails(String number) {
		return repository.findAllByNumber(number);
	}


}
