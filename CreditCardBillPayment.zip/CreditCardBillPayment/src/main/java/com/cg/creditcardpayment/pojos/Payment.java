package com.cg.creditcardpayment.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Payment_Master")
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "payment_id")

	private long id;
	@NotEmpty(message = "Payment type should not be empty")
	@Size(min = 4, message = "min 4 chars required")
	private String type;
	@NotEmpty(message = "Payment status should not be empty")
	@Size(min = 3, message = "min 3 chars required")
	private String status;

	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="card_id")
	private Transaction Transaction;
	/*
	 * default constructor.
	 */
	public Payment() {
		super();
		
	}
	/*
	 * Parameterized constructor.
	 */
	
	
	public Payment(long id,String type, String status,Transaction transaction) {
		super();
		this.id = id;
		this.type = type;
		this.status = status;
		Transaction = transaction;
	}

	public Payment(String type,String status,Transaction transaction) {
		super();
		this.type = type;
		this.status = status;
		Transaction = transaction;
	}
	@Override
	public String toString() {
		return "Payment [id=" + id + ", type=" + type + ", status=" + status + ", Transaction=" + Transaction + "]";
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Transaction getTransaction() {
		return Transaction;
	}

	public void setTransaction(Transaction transaction) {
		Transaction = transaction;
	}


	
}
