package com.cg.creditcardpayment.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.creditcardpayment.exceptions.AccountNotFoundException;
import com.cg.creditcardpayment.pojos.Transaction;
import com.cg.creditcardpayment.service.IStatementService;

@SpringBootTest
class StatementServiceTest {

	@Autowired
	IStatementService statementService;
	
	@AfterAll
	static void tearDownAfterClass() throws Exception {

	}

	@AfterEach
	void tearDown() throws AccountNotFoundException {
		System.out.println("Clean up complete");
	}
	@Test
	void testGetAllTransactionsBetweenDates() {
		String str="2019-03-31";  
	    Date startDate=Date.valueOf(str);
	    String str1="2020-03-31";  
	    Date endDate=Date.valueOf(str1);
		List<Transaction> list = statementService.getAllTransactionsBetweenDates("9657841236547851",startDate, endDate);
		assertTrue(list.isEmpty());
	}
	


}
