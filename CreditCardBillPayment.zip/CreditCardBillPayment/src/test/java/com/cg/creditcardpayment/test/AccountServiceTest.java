package com.cg.creditcardpayment.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.creditcardpayment.exceptions.AccountNotFoundException;
import com.cg.creditcardpayment.pojos.Account;
import com.cg.creditcardpayment.service.IAccountService;

@SpringBootTest
class AccountServiceTest {

	@Autowired
	IAccountService accountService;

	@AfterAll
	static void tearDownAfterClass() throws Exception {

	}

	@AfterEach
	void tearDown() throws AccountNotFoundException {
		System.out.println("Clean up complete");
	}

	@Test
	void testAddAccount()  {
		Account account1 = new Account("James", 5000, "Savings");
		Account account2 = accountService.addAccount(account1);
		assertEquals(account1, account2);
		System.out.println("Account has been added");
	}

	@Test
	void testDeleteAccount(){
		List<Account> account = accountService.deleteAccount(1);
		assertNotNull(account);
	}
	
	@Test
	void testDeleteAccountException()  throws AccountNotFoundException{
		long number = 250;
		assertThrows(AccountNotFoundException.class, () -> accountService.deleteAccount(number));
		System.err.println("No account is present with "+number);
	}


	@Test
	void testUpdateAccount() {
		Account account1 = new Account(1, "James", 7500, "Savings");
		Account returnAccount = accountService.updateAccount(account1);
		assertEquals(account1.getNumber(), returnAccount.getNumber());
		System.out.println(" Account updated successfully");
	}
	
	@Test
	void testUpdateAccountException()  throws AccountNotFoundException{
		Account account1 = new Account(60, "James", 7500, "Savings");
		assertThrows(AccountNotFoundException.class, () -> accountService.updateAccount(account1));
		System.err.println("Update not successful");
	}


	@Test
	void testGetAccount() {
		Account account = accountService.getAccount(1);
		assertNotNull(account);
	}
	
	@Test
	void testGetAccountException()  throws AccountNotFoundException{
		long id=850;
		assertThrows(AccountNotFoundException.class, () -> accountService.getAccount(id));
		System.err.println("Account cannot be retrieved");
	}

	
	@Test
	void testGetAllAccounts() {
		List<Account> account = accountService.getAllAccounts();
		assertTrue(!account.isEmpty());
		System.out.println("Printing all accounts");
	}

}
