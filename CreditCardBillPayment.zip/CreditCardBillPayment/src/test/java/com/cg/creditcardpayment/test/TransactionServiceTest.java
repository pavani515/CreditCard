package com.cg.creditcardpayment.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.creditcardpayment.exceptions.TransactionNotFoundException;
import com.cg.creditcardpayment.pojos.Transaction;
import com.cg.creditcardpayment.service.ITransactionService;

@SpringBootTest
class TransactionServiceTest {

	@Autowired
	ITransactionService transactionService;

	@AfterAll
	static void tearDownAfterClass() throws Exception {

	}

	@AfterEach
	void tearDown() throws TransactionNotFoundException {
		System.out.println("Clean up complete");
	}
	
	@Test
	void testAddTransaction() {
		long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis); 
		Transaction transaction1 = new Transaction("Paid", date, LocalTime.now(), "9657841236547851", "james@gmail.com", "9003641156", 6500.0, "Online");
		Transaction transaction2 = transactionService.addTransaction(transaction1);
		assertEquals(transaction1, transaction2);
		System.out.println("Transaction has been added");
	}

	@Test
	void testDeleteTransaction() {
		List<Transaction> transaction = transactionService.deleteTransaction(11);
		assertNotNull(transaction);
	}
	
	@Test
	void testDeleteTransactionException()  throws TransactionNotFoundException{
		int number = 290;
		assertThrows(TransactionNotFoundException.class, () -> transactionService.deleteTransaction(number));
		System.err.println("No transaction is present with "+number);
	}

	@Test
	void testUpdateTransaction() {
		long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis); 
		Transaction transaction1 = new Transaction("Paid",8, date, LocalTime.now(), "9657841236547851", "james20@gmail.com", "9003641156", 6500.0, "Online");
		Transaction returnTransaction = transactionService.updateTransaction(transaction1);
		assertEquals(transaction1.getNumber(), returnTransaction.getNumber());
		System.out.println(" Account updated successfully");
	}
	
	@Test
	void testUpdateTransactionException()  throws TransactionNotFoundException{
		assertThrows(TransactionNotFoundException.class, () -> transactionService.deleteTransaction(697));
		System.err.println("Update not successful");
	}


	@Test
	void testGetTransaction() {
		Transaction transaction = transactionService.getTransaction(8);
		assertNotNull(transaction);
	}
	
	@Test
	void testGetTransactionException()  throws TransactionNotFoundException{
		int number=349;
		assertThrows(TransactionNotFoundException.class, () -> transactionService.getTransaction(number));
		System.err.println("Transaction cannot be retrieved");
	}

	@Test
	void testGetAllTransactions() {
		List<Transaction> transaction = transactionService.getAllTransactions();
		assertTrue(!transaction.isEmpty());
		System.out.println("Printing all transactions");
	}

	@Test
	void testGetAllCardTransactions() {
		List<Transaction> transaction = transactionService.getAllCardTransactions("9657841236547851");
		assertTrue(!transaction.isEmpty());
		System.out.println("Printing all transactions");
	}

}
