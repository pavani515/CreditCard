package com.cg.creditcardpayment.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.creditcardpayment.exceptions.AccountNotFoundException;
import com.cg.creditcardpayment.exceptions.PaymentNotFoundException;
import com.cg.creditcardpayment.pojos.Payment;
import com.cg.creditcardpayment.pojos.Transaction;
import com.cg.creditcardpayment.service.IPaymentService;

@SpringBootTest
class PaymentServiceTest {

	@Autowired
	IPaymentService paymentService;
	
	@AfterAll
	static void tearDownAfterClass() throws Exception {

	}

	@AfterEach
	void tearDown() throws AccountNotFoundException {
		System.out.println("Clean up complete");
	}
	
	@Test
	void testAddPayment() {
		long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis); 
		Transaction transaction = new Transaction("Paid", date, LocalTime.now(), "9657841236547851", "james@gmail.com", "9003641156", 6500.0, "Online");
		Payment payment = new Payment("Online", "Paid", transaction);
		Payment payment1 = paymentService.addPayment(payment);
		assertEquals(payment, payment1);
		System.out.println("Payment has been added");
	}

	@Test
	void testRemovePayment() {
		List<Payment> payment = paymentService.removePayment(16);
		assertNotNull(payment);
	}
	
	@Test
	void testRemovePaymentException()  throws PaymentNotFoundException{
		long number = 176;
		assertThrows(PaymentNotFoundException.class, () -> paymentService.removePayment(number));
		System.err.println("No payment is present with "+number);
	}

	@Test
	void testUpdatePayment() {
		long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis); 
		Transaction transaction = new Transaction("Paid", date, LocalTime.now(), "9657841236547851", "james@gmail.com", "9003641156", 6500.0, "Online");
		Payment payment = new Payment(20, "Online","Fail", transaction);
		Payment returnPayment = paymentService.updatePayment(payment);
		assertEquals(payment.getId(), returnPayment.getId());
		System.out.println("Payment updated successfully");
	}
	
	@Test
	void testUpdatePaymentException()  throws PaymentNotFoundException{
		long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis); 
		Transaction transaction = new Transaction("Paid", date, LocalTime.now(), "9657841236547851", "james@gmail.com", "9003641156", 6500.0, "Online");
		Payment payment = new Payment(253, "Online","Fail", transaction);
		assertThrows(PaymentNotFoundException.class, () -> paymentService.updatePayment(payment));
		System.err.println("Update not successful");
	}

	@Test
	void testGetPayment() {
		Payment payment = paymentService.getPayment(23);
		assertNotNull(payment);
	}
	
	@Test
	void testGetPaymentException()  throws PaymentNotFoundException{
		long id=970;
		assertThrows(PaymentNotFoundException.class, () -> paymentService.getPayment(id));
		System.err.println("Payment Details cannot be retrieved");
	}

	@Test
	void testGetAllPayments() {
		List<Payment> payment = paymentService.getAllPayments();
		assertTrue(!payment.isEmpty());
		System.out.println("Printing all payments");
	}

}
