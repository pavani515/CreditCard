package com.cg.creditcardpayment.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.creditcardpayment.exceptions.CreditCardNotFoundException;
import com.cg.creditcardpayment.pojos.CreditCard;
import com.cg.creditcardpayment.service.ICreditCardService;

@SpringBootTest
class CreditCardServiceTest {

	@Autowired
	ICreditCardService service;

	@AfterAll
	static void tearDownAfterClass() throws Exception {

	}

	@AfterEach
	void tearDown() throws CreditCardNotFoundException {
		System.out.println("Clean up complete");
	}

	@Test
	void testAddCreditCard() {
		CreditCard card = new CreditCard("SBI Bank", "platinum", "master", "6789012345678901", LocalDate.now(), 234);
		CreditCard card1 = service.addCreditCard(card);
		assertEquals(card, card1);
		System.out.println("added sucessful");
	}

	@Test
	void testGetCreditCard(){
		CreditCard card = service.getCreditCard(5);
		assertNotNull(card);
	}
	
	@Test
	void testGetCreditCardException()  throws CreditCardNotFoundException{
		long id=850;
		assertThrows(CreditCardNotFoundException.class, () -> service.getCreditCard(id));
		System.err.println("Credit card cannot be retrieved");
	}

	@Test
	void testGetAllCreditCards() {
		List<CreditCard> card = service.getAllCreditCards();
		assertTrue(!card.isEmpty());
		System.out.println("Printing all Credit Cards");
	}

	@Test
	void testUpdateCreditCard() {
		CreditCard card1 = new CreditCard(3, "Kotak", "platinum", "master", "6789012345678901", LocalDate.now(), 253);
		CreditCard returnCard = service.updateCreditCard(card1);
		assertEquals(card1.getId(), returnCard.getId());
		System.out.println(" Credit card updated successfully");

	}
	
	@Test
	void testUpdateCreditCardException()  throws CreditCardNotFoundException{
		CreditCard card = new CreditCard(520,"SBI Bank", "platinum", "master", "6789012345678901", LocalDate.now(), 234);
		assertThrows(CreditCardNotFoundException.class, () -> service.updateCreditCard(card));
		System.err.println("Update not successful");
	}


	@Test
	void testDeleteCreditCard() {
		List<CreditCard> card = service.deleteCreditCard(8);
		assertNotNull(card);
	}
	
	@Test
	void testDeleteCreditCardException()  throws CreditCardNotFoundException{
		long number = 250;
		assertThrows(CreditCardNotFoundException.class, () -> service.deleteCreditCard(number));
		System.err.println("No credit card is present with "+number);
	}


	@Test
	void testGetAllCardDetails() {
		List<CreditCard> card = service.getAllCardDetails("6789012345678901");
		assertTrue(!card.isEmpty());
		System.out.println("Printing all Credit cards");
	}

}
