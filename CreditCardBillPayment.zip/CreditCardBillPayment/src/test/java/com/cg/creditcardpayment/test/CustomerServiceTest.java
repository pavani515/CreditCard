package com.cg.creditcardpayment.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.creditcardpayment.exceptions.CustomerNotFoundException;
import com.cg.creditcardpayment.pojos.Account;
import com.cg.creditcardpayment.pojos.CreditCard;
import com.cg.creditcardpayment.pojos.Customer;
import com.cg.creditcardpayment.service.ICustomerService;

@SpringBootTest
class CustomerServiceTest {
	
	@Autowired
	ICustomerService customerService;
	
	@AfterAll
	static void tearDownAfterClass() throws Exception {

	}

	@AfterEach
	void tearDown() throws CustomerNotFoundException {
		System.out.println("Clean up complete");
	}

	@Test
	void testAddCustomer() {
		List<Account> list = new ArrayList<Account>();
		Account account = new Account("James", 5000, "Savings");
		list.add(account);
		List<CreditCard> list1 = new ArrayList<CreditCard>();
		CreditCard card = new CreditCard("SBI Bank", "platinum", "master", "6789012345678901", LocalDate.now(), 234);
		list1.add(card);
		Customer customer1 = new Customer("Jason", "jason@gmail.com","9334768850",LocalDate.now(), "Melbourne", list,list1);
		Customer customer2 = customerService.addCustomer(customer1);
		assertEquals(customer1, customer2);
		System.out.println("Customer has been added");
	}

	@Test
	void testDeleteCustomer() {
		List<Customer> customer = customerService.deleteCustomer(31);
		assertNotNull(customer);
	}

	@Test
	void testDeleteCustomerException()  throws CustomerNotFoundException{
		int number = 250;
		assertThrows(CustomerNotFoundException.class, () -> customerService.deleteCustomer(number));
		System.err.println("No customer is present with "+number);
	}
	
	@Test
	void testUpdateCustomer() {
		List<Account> list = new ArrayList<Account>();
		Account account = new Account("James", 5000, "Savings");
		list.add(account);
		List<CreditCard> list1 = new ArrayList<CreditCard>();
		CreditCard card = new CreditCard("SBI Bank", "platinum", "master", "6789012345678901", LocalDate.now(), 234);
		list1.add(card);
		Customer customer1 = new Customer(34,"Jack", "jason@gmail.com","9334768850",LocalDate.now(), "Melbourne", list,list1);
		Customer returnCustomer = customerService.addCustomer(customer1);
		assertEquals(customer1.getUserId(), returnCustomer.getUserId());
		System.out.println("Customer updated successfully");
	}
	
	@Test
	void testUpdateCustomerException()  throws CustomerNotFoundException{
		List<Account> list = new ArrayList<Account>();
		Account account = new Account("James", 5000, "Savings");
		list.add(account);
		List<CreditCard> list1 = new ArrayList<CreditCard>();
		CreditCard card = new CreditCard("SBI Bank", "platinum", "master", "6789012345678901", LocalDate.now(), 234);
		list1.add(card);
		Customer customer1 = new Customer(536,"Jack", "jason@gmail.com","9334768850",LocalDate.now(), "Melbourne", list,list1);		
		assertThrows(CustomerNotFoundException.class, () -> customerService.updateCustomer(customer1));
		System.err.println("Update not successful");
	}

	@Test
	void testGetCustomer() {
		Customer customer = customerService.getCustomer(37);
		assertNotNull(customer);
	}
	
	@Test
	void testGetCustomerException()  throws CustomerNotFoundException{
		int id=900;
		assertThrows(CustomerNotFoundException.class, () -> customerService.getCustomer(id));
		System.err.println("Customer Details cannot be retrieved");
	}

	@Test
	void testGetAllCustomers() {
		List<Customer> customer = customerService.getAllCustomers();
		assertTrue(!customer.isEmpty());
		System.out.println("Printing all customers");
	}

}
